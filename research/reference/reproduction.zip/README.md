# Reproduction bundle

Run `python3 reproduce.py` (Python 3.10+, standard library only).

SYNTHETIC normalized observations included. These are not genuine Solana performance.

The script verifies source, dataset, manifest and exact results. Hashes prove consistency, not accuracy, profitability or an unseen historical holdout. No credentials are included.
