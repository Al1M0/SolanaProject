"""Offline reproduction; standard-library Python 3.10+. No provider requests."""
import argparse, json
from pathlib import Path
from app.engine import digest
from app.experiments import validate_snapshot, train_experiment, evaluate_experiment
p=argparse.ArgumentParser()
p.add_argument('--dataset', help='Authorized original dataset if redistribution was not permitted')
a=p.parse_args()
root=Path(__file__).parent
checks=json.loads((root/'checksums.json').read_text())
import hashlib
for name, expected in checks.items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:
        raise SystemExit('Bundle checksum mismatch: '+name)
m=json.loads((root/'manifest.json').read_text())
path=Path(a.dataset) if a.dataset else root/'dataset.json'
if not path.exists():
    raise SystemExit('Dataset excluded due to unconfirmed redistribution rights. Supply --dataset /authorized/original.json')
d=json.loads(path.read_text())
validate_snapshot(m,d)
expected=json.loads((root/'results.json').read_text())
actual=train_experiment(d,m)
actual['holdout']=evaluate_experiment(d,m,digest(m)) if expected.get('holdout') else None
if digest(actual)!=digest(expected):
    raise SystemExit('Result mismatch; exact fingerprints and all results must match')
print(json.dumps({'reproduced':True,'experiment_id':m['experiment_id'],'manifest_hash':digest(m),'results_hash':digest(actual)}))
